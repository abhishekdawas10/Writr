declare const _default: {
    isTableCellNode: (node: any) => boolean;
    isListNode: (editor: any) => (node: any) => any;
    getSelectedStyleType: (editor: any) => any;
};
export default _default;
