declare const _default: {
    applyListFormat: (editor: any, listName: any, styleValue: any) => void;
};
export default _default;
