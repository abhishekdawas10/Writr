declare const _default: {
    getNumberStyles: (editor: any) => any;
    getBulletStyles: (editor: any) => any;
};
export default _default;
