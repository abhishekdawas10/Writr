declare const _default: {
    toMenuItems: (styles: any) => any[];
};
export default _default;
