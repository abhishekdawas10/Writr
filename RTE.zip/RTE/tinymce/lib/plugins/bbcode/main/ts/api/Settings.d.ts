declare const _default: {
    getDialect: (editor: any) => any;
};
export default _default;
