declare const _default: {
    html2bbcode: (s: any) => any;
    bbcode2html: (s: any) => any;
};
export default _default;
