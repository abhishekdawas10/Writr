declare const _default: {
    parse: (time: any, defaultTime: any) => number;
};
export default _default;
