declare const _default: {
    fireRestoreDraft: (editor: any) => any;
    fireStoreDraft: (editor: any) => any;
    fireRemoveDraft: (editor: any) => any;
};
export default _default;
