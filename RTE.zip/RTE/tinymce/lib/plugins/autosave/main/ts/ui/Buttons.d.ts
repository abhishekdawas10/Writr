declare const _default: {
    register: (editor: any, started: any) => void;
};
export default _default;
