declare const _default: {
    shouldAskBeforeUnload: (editor: any) => any;
    getAutoSavePrefix: (editor: any) => any;
    shouldRestoreWhenEmpty: (editor: any) => any;
    getAutoSaveInterval: (editor: any) => number;
    getAutoSaveRetention: (editor: any) => number;
};
export default _default;
