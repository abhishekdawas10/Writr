declare const _default: {
    get: (editor: any) => {
        hasDraft: () => any;
        storeDraft: () => any;
        restoreDraft: () => any;
        removeDraft: () => any;
        isEmpty: () => any;
    };
};
export default _default;
