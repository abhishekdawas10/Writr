declare const _default: {
    type: (editor: any, chr: any) => void;
    typeString: (editor: any, str: any) => void;
};
export default _default;
