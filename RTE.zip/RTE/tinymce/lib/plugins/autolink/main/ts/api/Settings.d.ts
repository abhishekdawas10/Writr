declare const _default: {
    getAutoLinkPattern: (editor: any) => any;
    getDefaultLinkTarget: (editor: any) => any;
};
export default _default;
