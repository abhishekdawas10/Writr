declare const _default: {
    get: (editor: any) => {
        getCharMap: () => any;
        insertChar: (chr: any) => void;
    };
};
export default _default;
