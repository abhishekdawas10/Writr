declare const _default: {
    fireInsertCustomChar: (editor: any, chr: any) => any;
};
export default _default;
