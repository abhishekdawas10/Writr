declare const _default: {
    isValidId: (id: any) => boolean;
    getId: (editor: any) => any;
    insert: (editor: any, id: any) => void;
};
export default _default;
