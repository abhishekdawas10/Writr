declare const _default: {
    open: (editor: any) => void;
};
export default _default;
