declare const _default: {
    getAutoResizeMinHeight: (editor: any) => number;
    getAutoResizeMaxHeight: (editor: any) => number;
    getAutoResizeOverflowPadding: (editor: any) => any;
    getAutoResizeBottomMargin: (editor: any) => any;
    shouldAutoResizeOnInit: (editor: any) => any;
};
export default _default;
