declare const _default: {
    setup: (editor: any, oldSize: any) => void;
    resize: (editor: any, oldSize: any) => void;
};
export default _default;
