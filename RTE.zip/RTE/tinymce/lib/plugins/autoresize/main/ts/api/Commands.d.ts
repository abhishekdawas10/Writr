declare const _default: {
    register: (editor: any, oldSize: any) => void;
};
export default _default;
