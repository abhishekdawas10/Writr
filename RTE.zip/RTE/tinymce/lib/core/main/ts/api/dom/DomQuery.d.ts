declare const DomQuery: any;
export default DomQuery;
