declare const Class: any;
export default Class;
