declare let EditorManager: any;
export default EditorManager;
