declare const _default: {
    serialize: (o: any, quote?: any) => any;
    parse(text: any): any;
};
export default _default;
