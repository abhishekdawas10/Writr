declare let tinymce: any;
export default tinymce;
