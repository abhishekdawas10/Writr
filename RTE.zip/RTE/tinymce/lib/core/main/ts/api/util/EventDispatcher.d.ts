declare const Dispatcher: any;
export default Dispatcher;
