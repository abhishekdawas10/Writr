export default function (editor: any): void;
