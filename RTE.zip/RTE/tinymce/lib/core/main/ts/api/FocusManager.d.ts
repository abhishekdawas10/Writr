declare const _default: {
    isEditorUIElement: (elm: Element) => boolean;
};
export default _default;
