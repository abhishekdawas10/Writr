declare const _default: {
    fire(name: any, args: any, bubble: any): any;
    on(name: any, callback: any, prepend: any): any;
    off(name: any, callback: any): any;
    once(name: any, callback: any): any;
    hasEventListeners(name: any): any;
};
export default _default;
