import { Editor } from 'tinymce/core/api/Editor';
export interface UrlObject {
    prefix: string;
    resource: string;
    suffix: string;
}
export interface AddOnManager {
    items: any[];
    urls: Record<string, string>;
    lookup: {};
    _listeners: any[];
    get: (name: string) => any;
    dependencies: (name: string) => any;
    requireLangPack: (name: string, languages: string) => void;
    add: (id: string, addOn: (editor: Editor, url: string) => any, dependencies?: any) => (editor: Editor, url: string) => any;
    remove: (name: string) => void;
    createUrl: (baseUrl: UrlObject, dep: string | UrlObject) => UrlObject;
    addComponents: (pluginName: string, scripts: string[]) => void;
    load: (name: string, addOnUrl: string | UrlObject, success?: any, scope?: any, failure?: any) => void;
    waitFor: (name: string, callback: Function) => void;
}
export declare function AddOnManager(): AddOnManager;
export declare namespace AddOnManager {
    let language: any;
    let languageLoad: any;
    let baseURL: any;
    const PluginManager: AddOnManager;
    const ThemeManager: AddOnManager;
}
