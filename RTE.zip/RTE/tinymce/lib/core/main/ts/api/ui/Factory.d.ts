declare const _default: {
    add(type: any, typeClass: any): void;
    has(type: any): boolean;
    get(type: any): any;
    create(type: any, settings?: any): any;
};
export default _default;
