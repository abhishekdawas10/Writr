declare const Sizzle: any;
export default Sizzle;
