declare const _default: {
    callbacks: {};
    count: number;
    send(settings: any): void;
};
export default _default;
