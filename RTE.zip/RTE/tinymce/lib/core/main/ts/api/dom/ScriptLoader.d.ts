declare const ScriptLoader: any;
export default ScriptLoader;
