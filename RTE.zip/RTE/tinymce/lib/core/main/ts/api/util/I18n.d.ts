declare const _default: {
    setCode(newCode: any): void;
    getCode(): string;
    rtl: boolean;
    add(code: any, items: any): void;
    translate(text: any): any;
    data: {};
};
export default _default;
