declare const _default: PromiseConstructor;
export default _default;
