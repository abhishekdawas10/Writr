export declare type EditorEvent<T> = T & {
    isDefaultPrevented: () => boolean;
    isPropagationStopped: () => boolean;
    isImmediatePropagationStopped: () => boolean;
};
/**
 * This class enables you to bind/unbind native events to elements and normalize it's behavior across browsers.
 */
declare const EventUtils: any;
export default EventUtils;
