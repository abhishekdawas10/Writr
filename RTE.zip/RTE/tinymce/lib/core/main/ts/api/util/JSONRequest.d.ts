declare const JSONRequest: any;
export default JSONRequest;
