/**
 * ThemeManager.js
 *
 * Released under LGPL License.
 * Copyright (c) 1999-2017 Ephox Corp. All rights reserved
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */
import { UrlObject, AddOnManager } from './AddOnManager';
import { Editor } from 'tinymce/core/api/Editor';
export interface ThemeManager extends AddOnManager {
    add: (id: string, addOn: (editor: Editor, url: string) => any, dependencies?: any) => (editor: Editor, url: string) => any;
    createUrl: (baseUrl: UrlObject, dep: string | UrlObject) => UrlObject;
}
declare const _default: ThemeManager;
export default _default;
