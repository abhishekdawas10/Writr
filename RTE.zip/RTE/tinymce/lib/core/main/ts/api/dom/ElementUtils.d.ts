import { DOMUtils } from 'tinymce/core/api/dom/DOMUtils';
declare const ElementUtils: (dom: DOMUtils) => void;
export default ElementUtils;
