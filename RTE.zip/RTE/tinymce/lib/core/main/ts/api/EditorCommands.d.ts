import { Editor } from 'tinymce/core/api/Editor';
export default function (editor: Editor): void;
