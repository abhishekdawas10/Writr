/**
 * Settings.js
 *
 * Released under LGPL License.
 * Copyright (c) 1999-2016 Ephox Corp. All rights reserved
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */
import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    getIframeAttrs: (editor: Editor) => Record<string, string>;
    getDocType: (editor: Editor) => string;
    getDocumentBaseUrl: (editor: Editor) => string;
    getBodyId: (editor: Editor) => string;
    getBodyClass: (editor: Editor) => string;
    getContentSecurityPolicy: (editor: Editor) => string;
    shouldPutBrInPre: (editor: Editor) => boolean;
    getForcedRootBlock: (editor: Editor) => string;
    getForcedRootBlockAttrs: (editor: Editor) => Record<string, string>;
    getBrNewLineSelector: (editor: Editor) => string;
    getNoNewLineSelector: (editor: Editor) => string;
    shouldKeepStyles: (editor: Editor) => boolean;
    shouldEndContainerOnEmptyBlock: (editor: Editor) => boolean;
    getFontStyleValues: (editor: Editor) => string[];
    getFontSizeClasses: (editor: Editor) => string[];
};
export default _default;
