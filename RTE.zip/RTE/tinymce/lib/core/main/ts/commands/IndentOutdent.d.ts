import { Editor } from 'tinymce/core/api/Editor';
export declare const handle: (editor: Editor, command: string) => void;
