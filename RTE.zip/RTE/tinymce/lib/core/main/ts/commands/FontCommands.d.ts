/**
 * FontCommands.js
 *
 * Released under LGPL License.
 * Copyright (c) 1999-2016 Ephox Corp. All rights reserved
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */
import { Editor } from 'tinymce/core/api/Editor';
export declare const fontNameAction: (editor: Editor, value: string) => void;
export declare const fontNameQuery: (editor: Editor) => string;
export declare const fontSizeAction: (editor: Editor, value: string) => void;
export declare const fontSizeQuery: (editor: Editor) => string;
