declare const _default: {
    isZwsp: (chr: string) => boolean;
    ZWSP: string;
    trim: (text: string) => string;
};
export default _default;
