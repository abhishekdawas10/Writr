declare const hasStrongRtl: (text: string) => boolean;
export { hasStrongRtl };
