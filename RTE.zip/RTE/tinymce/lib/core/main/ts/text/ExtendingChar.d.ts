declare const isExtendingChar: (ch: string) => boolean;
export { isExtendingChar };
