declare const _default: {
    uriToBlob: (url: any) => Promise<{}>;
    blobToDataUri: (blob: any) => Promise<{}>;
    parseDataUri: (uri: any) => {
        type: any;
        data: any;
    };
};
export default _default;
