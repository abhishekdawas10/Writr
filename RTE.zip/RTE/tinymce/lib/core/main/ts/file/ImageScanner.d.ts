export default function (uploadStatus: any, blobCache: any): {
    findAll: (elm: any, predicate?: any) => Promise<any[]>;
};
