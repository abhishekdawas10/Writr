declare const _default: {
    uuid: (prefix: any) => string;
};
export default _default;
