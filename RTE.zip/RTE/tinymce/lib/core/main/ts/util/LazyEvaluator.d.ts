declare const _default: {
    evaluateUntil: (fns: any, args: any) => any;
};
export default _default;
