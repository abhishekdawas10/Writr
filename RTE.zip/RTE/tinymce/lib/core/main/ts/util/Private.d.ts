declare const _default: {
    create: () => {
        getOr: (obj: any, defaultValue: any) => any;
        set: (obj: any, value: any) => void;
    };
};
export default _default;
