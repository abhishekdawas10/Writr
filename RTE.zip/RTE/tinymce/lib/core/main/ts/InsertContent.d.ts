declare const _default: {
    insertAtCaret: (editor: any, value: any) => void;
};
export default _default;
