declare const _default: {
    setMode: (editor: any, mode: any) => void;
};
export default _default;
