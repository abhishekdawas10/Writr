declare const _default: {
    mergeBlocks: (rootNode: any, forward: any, block1: any, block2: any) => any;
};
export default _default;
