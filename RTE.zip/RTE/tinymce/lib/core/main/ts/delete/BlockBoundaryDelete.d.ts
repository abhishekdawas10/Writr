declare const _default: {
    backspaceDelete: (editor: any, forward: any) => any;
};
export default _default;
