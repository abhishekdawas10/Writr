import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    backspaceDelete: (editor: Editor, forward: any) => any;
    paddEmptyElement: (editor: Editor) => boolean;
};
export default _default;
