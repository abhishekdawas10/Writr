declare const _default: {
    backspaceDelete: (editor: any, forward: any) => boolean;
};
export default _default;
