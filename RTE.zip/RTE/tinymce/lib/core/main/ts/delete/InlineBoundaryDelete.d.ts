declare const _default: {
    backspaceDelete: (editor: any, caret: any, forward?: any) => any;
};
export default _default;
