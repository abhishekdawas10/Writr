declare const _default: {
    deleteCommand: (editor: any) => void;
    forwardDeleteCommand: (editor: any) => void;
};
export default _default;
