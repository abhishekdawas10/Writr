declare const _default: {
    getParentBlock: (rootNode: any, elm: any) => any;
    paddEmptyBody: (editor: any) => void;
    willDeleteLastPositionInElement: (forward: any, fromPos: any, elm: any) => any;
};
export default _default;
