import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    backspaceDelete: (editor: Editor, forward?: boolean) => any;
};
export default _default;
