declare const _default: {
    deleteElement: (editor: any, forward: boolean, elm: any) => void;
};
export default _default;
