declare const _default: {
    register: (domParser: any, settings: any) => void;
};
export default _default;
