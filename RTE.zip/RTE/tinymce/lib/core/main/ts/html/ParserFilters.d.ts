declare const register: (parser: any, settings: any) => void;
export { register };
