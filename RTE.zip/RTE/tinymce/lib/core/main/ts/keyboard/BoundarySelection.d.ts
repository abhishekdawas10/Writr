/**
 * BoundarySelection.js
 *
 * Released under LGPL License.
 * Copyright (c) 1999-2017 Ephox Corp. All rights reserved
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */
import { Cell } from '@ephox/katamari';
import CaretPosition from '../caret/CaretPosition';
import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    move: (editor: Editor, caret: Cell<Text>, forward: boolean) => () => any;
    moveNextWord: (editor: Editor, caret: Cell<Text>) => () => boolean;
    movePrevWord: (editor: Editor, caret: Cell<Text>) => () => boolean;
    setupSelectedState: (editor: Editor) => Cell<Text>;
    setCaretPosition: (editor: Editor, pos: CaretPosition) => void;
};
export default _default;
