declare const _default: {
    readLocation: (isInlineTarget: any, rootNode: any, pos: any) => any;
    findLocation: (forward: any, isInlineTarget: any, rootNode: any, pos: any) => any;
    prevLocation: (...x: any[]) => any;
    nextLocation: (...x: any[]) => any;
    getElement: (location: any) => any;
    outside: (location: any) => any;
    inside: (location: any) => any;
};
export default _default;
