declare const moveH: (editor: any, forward: boolean) => () => boolean;
declare const moveV: (editor: any, down: boolean) => () => boolean;
export { moveH, moveV };
