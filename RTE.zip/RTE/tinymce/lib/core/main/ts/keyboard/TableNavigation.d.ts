declare const isFakeCaretTableBrowser: () => boolean;
declare const moveH: (editor: any, forward: boolean) => () => boolean;
declare const moveV: (editor: any, forward: boolean) => () => boolean;
export { isFakeCaretTableBrowser, moveH, moveV };
