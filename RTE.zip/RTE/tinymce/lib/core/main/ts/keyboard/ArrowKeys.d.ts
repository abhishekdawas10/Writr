import { Editor } from 'tinymce/core/api/Editor';
import { Cell } from '@ephox/katamari';
declare const _default: {
    setup: (editor: Editor, caret: Cell<Text>) => void;
};
export default _default;
