declare const _default: {
    insertAtSelection: (editor: any) => any;
};
export default _default;
