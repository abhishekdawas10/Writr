/**
 * InlineUtils.js
 *
 * Released under LGPL License.
 * Copyright (c) 1999-2017 Ephox Corp. All rights reserved
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */
import { Option } from '@ephox/katamari';
import CaretPosition from '../caret/CaretPosition';
import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    isInlineTarget: (editor: Editor, elm: Node) => boolean;
    findRootInline: (isInlineTarget: (node: Node) => boolean, rootNode: Node, pos: CaretPosition) => Option<Node>;
    isRtl: (element: Node) => boolean;
    isAtZwsp: (pos: CaretPosition) => boolean;
    normalizePosition: (forward: boolean, pos: CaretPosition) => CaretPosition;
    normalizeForwards: (pos: CaretPosition) => CaretPosition;
    normalizeBackwards: (pos: CaretPosition) => CaretPosition;
    hasSameParentBlock: (rootNode: Node, node1: Node, node2: Node) => boolean;
};
export default _default;
