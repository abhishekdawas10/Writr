/**
 * MatchKeys.js
 *
 * Released under LGPL License.
 * Copyright (c) 1999-2017 Ephox Corp. All rights reserved
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */
import { Option } from '@ephox/katamari';
export interface KeyPattern {
    shiftKey?: boolean;
    altKey?: boolean;
    ctrlKey?: boolean;
    metaKey?: boolean;
    keyCode?: number;
    action: () => boolean;
}
declare const _default: {
    match: (patterns: KeyPattern[], evt: KeyboardEvent) => KeyPattern[];
    action: (f: any, ...x: any[]) => () => any;
    execute: (patterns: KeyPattern[], evt: KeyboardEvent) => Option<KeyPattern>;
};
export default _default;
