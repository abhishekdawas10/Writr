declare const _default: {
    toggle: (editor: any, formats: any, name: any, vars: any, node: any) => void;
};
export default _default;
