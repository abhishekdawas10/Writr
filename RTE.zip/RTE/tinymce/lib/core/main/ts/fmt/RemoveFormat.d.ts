declare const _default: {
    removeFormat: (ed: any, format: any, vars?: any, node?: any, compareNode?: any) => boolean;
    remove: (ed: any, name: any, vars?: any, node?: any, similar?: any) => void;
};
export default _default;
