declare const isCaretNode: (node: Node) => boolean;
declare const getParentCaretContainer: (body: any, node: any) => any;
export { isCaretNode, getParentCaretContainer };
