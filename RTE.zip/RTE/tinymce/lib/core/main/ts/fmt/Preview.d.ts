declare const _default: {
    getCssText: (editor: any, format: any) => string;
    parseSelector: (selector: any) => any[];
    selectorToHtml: (selector: any, editor?: any) => any;
};
export default _default;
