declare const _default: {
    applyFormat: (ed: any, name: any, vars?: any, node?: any) => void;
};
export default _default;
