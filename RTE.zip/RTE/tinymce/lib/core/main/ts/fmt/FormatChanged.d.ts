declare const _default: {
    formatChanged: (editor: any, formatChangeState: any, formats: any, callback: any, similar: any) => void;
};
export default _default;
