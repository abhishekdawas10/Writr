declare const _default: {
    getFontSize: (rootElm: Element, elm: Node) => string;
    getFontFamily: (rootElm: Element, elm: Node) => string;
    toPt: (fontSize: string, precision?: number) => string;
};
export default _default;
