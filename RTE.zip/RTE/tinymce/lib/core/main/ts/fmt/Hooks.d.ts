declare const _default: {
    postProcess: (name: any, editor: any) => void;
};
export default _default;
