declare const _default: {
    mergeWithChildren: (editor: any, formatList: any, vars: any, node: any) => void;
    mergeUnderlineAndColor: (dom: any, format: any, vars: any, node: any) => void;
    mergeBackgroundColorAndFontSize: (dom: any, format: any, vars: any, node: any) => void;
    mergeSubSup: (dom: any, format: any, vars: any, node: any) => void;
    mergeSiblings: (dom: any, format: any, vars: any, node: any) => void;
    mergeWithParents: (editor: any, format: any, name: any, vars: any, node: any) => void;
};
export default _default;
