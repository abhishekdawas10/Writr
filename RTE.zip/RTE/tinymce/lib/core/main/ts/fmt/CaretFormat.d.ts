import CaretPosition from '../caret/CaretPosition';
import { Editor } from 'tinymce/core/api/Editor';
declare const applyCaretFormat: (editor: any, name: any, vars: any) => void;
declare const removeCaretFormat: (editor: Editor, name: any, vars: any, similar: any) => void;
declare const setup: (editor: any) => void;
declare const replaceWithCaretFormat: (targetNode: any, formatNodes: any) => CaretPosition;
declare const isFormatElement: (editor: any, element: any) => boolean;
export { setup, applyCaretFormat, removeCaretFormat, replaceWithCaretFormat, isFormatElement };
