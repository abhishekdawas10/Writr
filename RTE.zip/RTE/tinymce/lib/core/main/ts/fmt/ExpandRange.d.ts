declare const _default: {
    expandRng: (editor: any, rng: any, format: any, remove?: any) => {
        startContainer: any;
        startOffset: any;
        endContainer: any;
        endOffset: any;
    };
};
export default _default;
