declare const _default: {
    setContent: (editor: any, content: any, args: any) => void;
};
export default _default;
