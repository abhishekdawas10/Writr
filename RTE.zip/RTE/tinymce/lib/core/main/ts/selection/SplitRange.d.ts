declare const _default: {
    split: (rng: any) => {
        startContainer: any;
        startOffset: any;
        endContainer: any;
        endOffset: any;
    };
};
export default _default;
