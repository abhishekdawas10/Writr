declare const _default: {
    walk: (dom: any, rng: any, callback: any) => any;
};
export default _default;
