declare const _default: {
    getContent: (editor: any, args: any) => any;
};
export default _default;
