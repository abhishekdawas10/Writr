/**
 * NormalizeRange.js
 *
 * Released under LGPL License.
 * Copyright (c) 1999-2017 Ephox Corp. All rights reserved
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */
import { Option } from '@ephox/katamari';
import { DOMUtils } from 'tinymce/core/api/dom/DOMUtils';
declare const _default: {
    normalize: (dom: DOMUtils, rng: Range) => Option<Range>;
};
export default _default;
