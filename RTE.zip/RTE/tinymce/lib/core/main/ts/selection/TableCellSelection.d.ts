declare const _default: {
    getCellsFromRanges: (ranges: any) => any[];
    getCellsFromElement: (elm: any) => any;
    getCellsFromElementOrRanges: (ranges: any, element: any) => any;
    getCellsFromEditor: (editor: any) => any;
};
export default _default;
