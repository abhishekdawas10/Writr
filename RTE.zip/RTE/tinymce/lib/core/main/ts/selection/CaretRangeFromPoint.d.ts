declare const _default: {
    fromPoint: (clientX: number, clientY: number, doc: Document) => Range;
};
export default _default;
