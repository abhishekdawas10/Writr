declare const _default: {
    getRanges: (selection: any) => any[];
    getSelectedNodes: (ranges: any) => any[];
    hasMultipleRanges: (selection: any) => boolean;
};
export default _default;
