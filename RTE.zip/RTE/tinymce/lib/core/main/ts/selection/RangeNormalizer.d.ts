declare const _default: {
    normalize: (rng: Range) => Range;
};
export default _default;
