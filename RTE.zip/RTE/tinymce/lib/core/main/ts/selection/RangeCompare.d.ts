declare const _default: {
    isEq: (rng1: Range, rng2: Range) => boolean;
};
export default _default;
