declare const hasAllContentsSelected: (elm: any, rng: any) => boolean;
declare const moveEndPoint: (dom: any, rng: Range, node: any, start: boolean) => void;
export { hasAllContentsSelected, moveEndPoint };
