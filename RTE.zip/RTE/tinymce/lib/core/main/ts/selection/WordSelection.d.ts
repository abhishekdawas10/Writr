import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    hasSelectionModifyApi: (editor: Editor) => any;
    moveByWord: (forward: boolean, editor: Editor) => boolean;
};
export default _default;
