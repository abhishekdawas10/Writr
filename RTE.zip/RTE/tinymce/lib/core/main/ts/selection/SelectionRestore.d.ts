declare const _default: {
    register: (editor: any) => void;
};
export default _default;
