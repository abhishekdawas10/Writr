declare const _default: {
    read: (rootNode: any, ranges: any) => any;
};
export default _default;
