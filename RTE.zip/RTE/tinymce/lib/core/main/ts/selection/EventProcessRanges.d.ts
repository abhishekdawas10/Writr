declare const _default: {
    processRanges: (editor: any, ranges: Range[]) => Range[];
};
export default _default;
