declare const _default: {
    read: (elm: any) => any[];
    write: (fragments: any, elm: any) => any;
};
export default _default;
