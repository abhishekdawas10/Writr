declare const _default: {
    KEEP: number;
    DELETE: number;
    INSERT: number;
    diff: (left: any, right: any) => any[];
};
export default _default;
