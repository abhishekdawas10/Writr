declare const _default: {
    isXYInContentArea: (editor: any, clientX: any, clientY: any) => boolean;
    isEditorAttachedToDom: (editor: any) => any;
};
export default _default;
