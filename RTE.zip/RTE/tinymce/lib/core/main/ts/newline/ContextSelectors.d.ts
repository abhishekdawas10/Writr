declare const _default: {
    shouldInsertBr: (editor: any) => boolean;
    shouldBlockNewLine: (editor: any) => boolean;
};
export default _default;
