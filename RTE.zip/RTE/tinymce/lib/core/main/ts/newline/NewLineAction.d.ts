declare const _default: {
    getAction: (editor: any, evt: any) => any;
};
export default _default;
