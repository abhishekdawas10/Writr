declare const _default: {
    insert: (editor: any, evt?: any) => void;
};
export default _default;
