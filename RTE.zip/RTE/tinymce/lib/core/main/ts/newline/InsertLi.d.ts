declare const _default: {
    insert: (editor: any, createNewBlock: any, containerBlock: any, parentBlock: any, newBlockName: any) => void;
};
export default _default;
