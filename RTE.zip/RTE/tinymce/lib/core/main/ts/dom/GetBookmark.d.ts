import { Selection } from '../api/dom/Selection';
declare const _default: {
    getBookmark: (selection: Selection, type: any, normalized: any) => any;
    getUndoBookmark: (...x: any[]) => any;
};
export default _default;
