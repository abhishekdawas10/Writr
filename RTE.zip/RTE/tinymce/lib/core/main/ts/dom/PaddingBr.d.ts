declare const _default: {
    removeTrailingBr: (elm: any) => void;
    fillWithPaddingBr: (elm: any) => void;
    isPaddedElement: (elm: any) => boolean;
    trimBlockTrailingBr: (elm: any) => void;
};
export default _default;
