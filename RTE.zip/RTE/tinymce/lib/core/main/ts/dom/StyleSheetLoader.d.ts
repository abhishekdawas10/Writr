/**
 * This class handles loading of external stylesheets and fires events when these are loaded.
 *
 * @class tinymce.dom.StyleSheetLoader
 * @private
 */
export interface StyleSheetLoader {
    load: (url: string, loadedCallback: Function, errorCallback?: Function) => void;
    loadAll: (urls: string[], success: Function, failure: Function) => void;
}
export declare function StyleSheetLoader(document: any, settings?: any): StyleSheetLoader;
