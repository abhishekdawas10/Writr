declare const _default: {
    calc: (editor: any, event: any) => {
        pageX: any;
        pageY: any;
    };
};
export default _default;
