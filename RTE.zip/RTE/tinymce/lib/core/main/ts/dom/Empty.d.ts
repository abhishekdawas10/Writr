declare const _default: {
    isEmpty: (elm: any) => boolean;
};
export default _default;
