import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    scrollElementIntoView: (editor: Editor, elm: HTMLElement, alignToTop: boolean) => void;
    scrollRangeIntoView: (editor: Editor, rng: Range) => void;
};
export default _default;
