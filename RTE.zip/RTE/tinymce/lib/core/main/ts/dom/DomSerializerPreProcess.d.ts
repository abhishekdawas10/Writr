declare const _default: {
    process: (editor: any, node: any, args: any) => any;
};
export default _default;
