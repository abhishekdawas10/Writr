declare const _default: {
    isXYWithinRange: (clientX: any, clientY: any, range: any) => boolean;
};
export default _default;
