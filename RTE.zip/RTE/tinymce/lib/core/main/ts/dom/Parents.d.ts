declare const _default: {
    parentsUntil: (startNode: any, rootElm: any, predicate: any) => any;
    parents: (startNode: any, rootElm: any) => any;
    parentsAndSelf: (startNode: any, rootElm: any) => any[];
};
export default _default;
