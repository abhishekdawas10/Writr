declare const _default: {
    create: (rootNode: any, targetNode: any, normalized?: any) => any[];
    resolve: (rootNode: any, path: any) => any;
};
export default _default;
