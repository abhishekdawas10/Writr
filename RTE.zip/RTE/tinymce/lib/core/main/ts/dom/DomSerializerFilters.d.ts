declare const _default: {
    register: (htmlParser: any, settings: any, dom: any) => void;
    trimTrailingBr: (rootNode: any) => void;
};
export default _default;
