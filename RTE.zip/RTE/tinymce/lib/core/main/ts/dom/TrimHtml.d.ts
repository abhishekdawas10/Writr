declare const _default: {
    trimExternal: (serializer: any, html: any) => string;
    trimInternal: (serializer: any, html: any) => string;
};
export default _default;
