declare const _default: {
    trimNode: (dom: any, node: any) => any;
};
export default _default;
