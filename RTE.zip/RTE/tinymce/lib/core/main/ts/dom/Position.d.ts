declare const _default: {
    getPos: (body: any, elm: any, rootElm: any) => {
        x: number;
        y: number;
    };
};
export default _default;
