declare const _default: {
    setup: (editorManager: any) => void;
    isEditorUIElement: (elm: any) => boolean;
    isUIElement: (editor: any, elm: any) => boolean;
};
export default _default;
