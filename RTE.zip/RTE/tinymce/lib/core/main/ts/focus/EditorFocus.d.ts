import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    focus: (editor: Editor, skipFocus: boolean) => void;
    hasFocus: (editor: Editor) => boolean;
};
export default _default;
