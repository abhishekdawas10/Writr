declare const _default: {
    setup: (editor: any) => void;
};
export default _default;
