declare const _default: {
    add: (editor: any, name: any, settings: any) => void;
};
export default _default;
