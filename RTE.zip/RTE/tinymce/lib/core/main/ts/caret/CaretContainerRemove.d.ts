import CaretPosition from './CaretPosition';
declare const _default: {
    removeAndReposition: (container: Node, pos: CaretPosition) => CaretPosition;
    remove: (caretContainerNode: Node) => void;
};
export default _default;
