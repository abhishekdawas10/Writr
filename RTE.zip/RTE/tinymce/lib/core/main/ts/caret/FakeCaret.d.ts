export interface FakeCaret {
    show: (before: boolean, element: Element) => Range;
    hide: () => void;
    getCss: () => string;
    reposition: () => void;
    destroy: () => void;
}
export declare const FakeCaret: (root: HTMLElement, isBlock: (node: Node) => boolean, hasFocus: () => boolean) => FakeCaret;
export declare const isFakeCaretTarget: (node: Node) => boolean;
