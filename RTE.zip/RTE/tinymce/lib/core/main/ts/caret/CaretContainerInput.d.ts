import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    setup: (editor: Editor) => void;
};
export default _default;
