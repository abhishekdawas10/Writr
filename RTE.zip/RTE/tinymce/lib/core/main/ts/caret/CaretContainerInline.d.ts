declare const insertInline: (before: boolean, node: Node) => Text;
declare const insertInlineBefore: (node: Node) => Text;
declare const insertInlineAfter: (node: Node) => Text;
export { insertInline, insertInlineBefore, insertInlineAfter };
