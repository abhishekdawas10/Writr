declare const _default: {
    init: (editor: any) => void;
};
export default _default;
