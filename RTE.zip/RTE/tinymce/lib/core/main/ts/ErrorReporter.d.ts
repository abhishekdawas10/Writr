declare const _default: {
    pluginLoadError: (editor: any, url: any) => void;
    uploadError: (editor: any, message: any) => void;
    displayError: (editor: any, message: any) => void;
    initError: (message: any, ...x: any[]) => void;
};
export default _default;
