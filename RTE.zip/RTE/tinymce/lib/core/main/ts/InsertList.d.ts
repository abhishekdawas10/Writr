declare const _default: {
    isListFragment: (schema: any, fragment: any) => boolean;
    insertAtCaret: (serializer: any, dom: any, rng: any, fragment: any) => Range;
    isParentBlockLi: (dom: any, node: any) => boolean;
    trimListItems: (elms: any) => any;
    listItems: (elm: any) => any[];
};
export default _default;
