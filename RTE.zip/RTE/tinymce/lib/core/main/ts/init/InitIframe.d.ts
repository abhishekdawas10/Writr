declare const _default: {
    init: (editor: any, boxInfo: any) => void;
};
export default _default;
