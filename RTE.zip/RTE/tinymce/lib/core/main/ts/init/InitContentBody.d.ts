import { Editor } from 'tinymce/core/api/Editor';
declare const _default: {
    initContentBody: (editor: Editor, skipWrite?: boolean) => void;
};
export default _default;
