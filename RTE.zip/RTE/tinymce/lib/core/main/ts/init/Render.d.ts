declare const _default: {
    render: (editor: any) => void;
};
export default _default;
