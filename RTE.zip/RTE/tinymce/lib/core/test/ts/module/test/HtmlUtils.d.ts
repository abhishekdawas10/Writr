declare const _default: {
    cleanHtml: (html: any) => any;
    normalizeHtml: (html: any) => string;
};
export default _default;
