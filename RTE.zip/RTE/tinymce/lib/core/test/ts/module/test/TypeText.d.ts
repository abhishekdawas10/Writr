declare const _default: {
    sTypeContentAtSelection: (doc: any, text: any) => (state: any, next: any, die: any) => void;
};
export default _default;
