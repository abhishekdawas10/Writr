declare const _default: {
    type: (editor: any, chr: any) => void;
};
export default _default;
