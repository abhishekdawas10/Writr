export default function (): void;
